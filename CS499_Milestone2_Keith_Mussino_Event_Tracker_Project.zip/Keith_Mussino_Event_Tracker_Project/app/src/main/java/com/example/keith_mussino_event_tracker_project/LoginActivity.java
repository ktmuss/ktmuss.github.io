package com.example.keith_mussino_event_tracker_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    //UI variables
    private EditText editUsername, editPassword;
    private Button buttonLogin, buttonCreateAccount;

    //database helper, interacts with SQLite
    private DatabaseHelper dbHelper;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        //links to XML layout
        setContentView(R.layout.login_activity);

        //initialize UI
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        //initialize db helper
        dbHelper = new DatabaseHelper(this);

        //sets click listener for login button
        buttonLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //gets user input
                String username = editUsername.getText().toString().trim();
                String password = editPassword.getText().toString().trim();

                //checks for empty input
                if (username.isEmpty() || password.isEmpty()) {

                    Toast.makeText(LoginActivity.this, "Please input into both fields",
                            Toast.LENGTH_SHORT).show();

                    return;
                }

                //validate credentials using db
                boolean isvalid = dbHelper.validLogin(username, password);

                if(isvalid){

                    Toast.makeText(LoginActivity.this, "Login Successful",
                            Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(LoginActivity.this, EventGridActivity.class));

                    finish();//prevents return to login screen

                } else {//login failed

                    Toast.makeText(LoginActivity.this, "Invalid login credentials, try again.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        //sets click listener to create account button
        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //get user input
                String username = editUsername.getText().toString().trim();
                String password = editPassword.getText().toString().trim();

                //checks if input is empty
                if (username.isEmpty() || password.isEmpty()) {

                    Toast.makeText(LoginActivity.this, "Please input in both fields",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                //attempt to register user in db
                boolean isRegistered = dbHelper.registerUser(username, password);

                    if (isRegistered) {//register was success, go to event screen

                        Toast.makeText(LoginActivity.this, "Account was created.",
                                Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(LoginActivity.this, EventGridActivity.class));

                        finish();//prevents return to login screen

                    } else {//credentials already exist

                        Toast.makeText(LoginActivity.this, "Account already exists", Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }
}

