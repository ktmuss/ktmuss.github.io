package com.example.keith_mussino_event_tracker_project;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.widget.Toast;

public class EventGridActivity extends AppCompatActivity{

    //UI variables
    private TableLayout eventTable;
    private EditText eventNameInput, eventDateInput;
    private Button addButton, buttonGoToSMS;

    //Sqlite helper
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_grid_activity);

        //get reference to UI
        eventTable = findViewById(R.id.eventTable);
        eventNameInput = findViewById(R.id.editEventName);
        eventDateInput = findViewById(R.id.editEventDate);
        addButton = findViewById(R.id.buttonAddEvent);
        buttonGoToSMS = findViewById(R.id.buttonGoToSMS);

        //DatabaseHelper instance
        dbHelper = new DatabaseHelper(this);

        //load events form database and display to app
        loadEventsFromDataBase();

        //set up add button
        addButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){

                String name = eventNameInput.getText().toString().trim();
                String date = eventDateInput.getText().toString().trim();

                //validate input fields
                if(!name.isEmpty() && !date.isEmpty()){

                    boolean added = dbHelper.addEvent(name, date);

                    if(added){

                        //clear fields
                        eventNameInput.setText("");
                        eventDateInput.setText("");

                        //refresh displayed event list

                        loadEventsFromDataBase();
                    }
                }
            }
        });

        //set listener to open sms screen
        buttonGoToSMS.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){

                startActivity(new Intent(EventGridActivity.this, SmsPermissionActivity.class));
            }
        });
    }

    //loads events form database
    //clears current display and repopulates to match current database state
    private void loadEventsFromDataBase() {

        //clear all rows before loading fresh data
        eventTable.removeAllViews();

        //query the database for all records
        Cursor cursor = dbHelper.getEvents();

        if (cursor != null && cursor.moveToFirst()) {

            //extract event fields form db
            do {

                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID_COLUMN));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_NAME_COLUMN));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE_COLUMN));

                //add a new row to table for event
                addEventRow(id, name, date);

            } while (cursor.moveToNext());

            //close cursor after use
            cursor.close();
        }
    }
    //adds new row to table
    private void addEventRow(int id, String name, String date){

        TableRow row = new TableRow(this);//create new table

        //create TextView for event name
        TextView nameColumn = new TextView(this);
        nameColumn.setText(name);
        nameColumn.setPadding(16,16,16,16);

        //create TextView for event date
        TextView dateColumn = new TextView(this);
        dateColumn.setText(date);
        dateColumn.setPadding(16,16,16,16);

        //creates delete button
        Button delete = new Button(this);
        delete.setText("Delete");

        //create Edit button
        Button edit = new Button(this);
        edit.setText("Edit");

        //sets click listener to delete event from db and refresh table
        delete.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){

                //remove row
                dbHelper.deleteEvent(id);//deletes data

                loadEventsFromDataBase();//refresh table
            }
        });

        //sets click listener to edit event
        edit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){

                showEditDialog(id, name, date);
            }
        });

            //add views to row
            row.addView(nameColumn);
            row.addView(dateColumn);
            row.addView(delete);
            row.addView(edit);

            //add row to table layout
            eventTable.addView(row);
        }

        //enhanced update
        //dialogue box for edit button
        //will open a popup dialog when clicked
        //allowing users to edit their event
        private void showEditDialog(int id, String currentName, String currentDate) {

            //create dialog
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Edit Event");

            //create layout for input fields
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(20, 20, 20, 20);

            final EditText nameInput = new EditText(this);
            nameInput.setHint("Event Name");
            nameInput.setText(currentName);
            layout.addView(nameInput);

            final EditText dateInput = new EditText(this);
            dateInput.setHint("Event Date");
            dateInput.setText(currentDate);
            layout.addView(dateInput);

            builder.setView(layout);

            //sets update button
            builder.setPositiveButton("Update", (dialog, which) -> {
                String newName = nameInput.getText().toString().trim();
                String newDate = dateInput.getText().toString().trim();

                    if(!newName.isEmpty() && !newDate.isEmpty()){

                        boolean updated = dbHelper.updateEvent(id, newName, newDate);

                        if(updated){
                            Toast.makeText(EventGridActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                            loadEventsFromDataBase();
                        } else {

                            Toast.makeText(EventGridActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                        }
                    } else{
                        Toast.makeText(EventGridActivity.this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                    }
            });

            //sets cancel button
            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

            builder.show();
        }
    }

