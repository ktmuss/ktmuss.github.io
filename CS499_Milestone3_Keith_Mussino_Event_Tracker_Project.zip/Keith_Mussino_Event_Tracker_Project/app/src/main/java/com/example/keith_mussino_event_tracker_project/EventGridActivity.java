package com.example.keith_mussino_event_tracker_project;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.widget.Toast;

//Enhancement update
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class EventGridActivity extends AppCompatActivity{

    //UI variables
    private RecyclerView recyclerEventList;//enhancement; used to display events
    private EventAdapter eventAdapter;//enhancement; binds data to event
    private EditText eventNameInput, eventDateInput;//input fields
    private Button addButton, buttonGoToSMS;//buttons for adding event and navigating to sms screen

    //Sqlite helper
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_grid_activity);//sets screen layout

        //get reference to UI
        recyclerEventList = findViewById(R.id.recyclerEventList);//enhancement
        recyclerEventList.setLayoutManager(new LinearLayoutManager(this));//enhancement; set vertical layout manager
        eventNameInput = findViewById(R.id.editEventName);
        eventDateInput = findViewById(R.id.editEventDate);
        addButton = findViewById(R.id.buttonAddEvent);
        buttonGoToSMS = findViewById(R.id.buttonGoToSMS);

        //DatabaseHelper instance
        dbHelper = new DatabaseHelper(this);

        //load events form database and display to app
        loadEventsFromDatabase();

        //add event button handler
        addButton.setOnClickListener(view -> {

                String name = eventNameInput.getText().toString().trim();
                String date = eventDateInput.getText().toString().trim();

                //validate input fields
                if(!name.isEmpty() && !date.isEmpty()){

                    boolean added = dbHelper.addEvent(name, date);//add event to db

                    if(added){

                        //clear fields
                        eventNameInput.setText("");
                        eventDateInput.setText("");

                        //refresh displayed event list
                        loadEventsFromDatabase();
                    }
                    else {

                        Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show();
                    }
                }
                else{

                    Toast.makeText(this, "Please enter both a name and a date", Toast.LENGTH_SHORT).show();
                }
        });

        //set listener to open sms screen
        buttonGoToSMS.setOnClickListener(view ->{

                startActivity(new Intent(EventGridActivity.this, SmsPermissionActivity.class));
        });
    }

    private void loadEventsFromDatabase(){

        List<Event> events = new ArrayList<>();
        Cursor cursor = dbHelper.getEvents();//query for events

        //converts cursor results into event objects
        if (cursor != null && cursor.moveToFirst()){

            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID_COLUMN));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_NAME_COLUMN));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE_COLUMN));

                events.add(new Event(id, name, date));//add event to list

            }while(cursor.moveToNext());

            cursor.close();
        }

        //create adapter if adapter is not initialized yet
        if(eventAdapter == null){

            eventAdapter = new EventAdapter(this, events, this::showEditDialog, event ->{

                dbHelper.deleteEvent(event.getId());//delete from db
                loadEventsFromDatabase(); //refreshes the list
                Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
            });

            recyclerEventList.setAdapter(eventAdapter);
        }
        else {//else, update data

            eventAdapter.updateEventList(events);
        }
    }

    //overloaded method that opens edit dialog with event object
    private void showEditDialog(Event event){

        showEditDialog(event.getId(), event.getName(), event.getDate());
    }

    //enhanced update
    //dialogue box for edit button
    //will open a popup dialog when clicked
    //allowing users to edit their event
    private void showEditDialog(int id, String currentName, String currentDate) {

        //create dialog
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Edit Event");

        //create layout for input fields
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20, 20, 20, 20);

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Event Name");
        nameInput.setText(currentName);
        layout.addView(nameInput);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Event Date");
        dateInput.setText(currentDate);
        layout.addView(dateInput);

        builder.setView(layout);

        //sets update button
        builder.setPositiveButton("Update", (dialog, which) -> {
            String newName = nameInput.getText().toString().trim();
            String newDate = dateInput.getText().toString().trim();

                if(!newName.isEmpty() && !newDate.isEmpty()){//validate changes

                    boolean updated = dbHelper.updateEvent(id, newName, newDate);

                    if(updated){
                        Toast.makeText(EventGridActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                        loadEventsFromDatabase();
                    } else {

                        Toast.makeText(EventGridActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                } else{
                    Toast.makeText(EventGridActivity.this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                }
        });

        //sets cancel button
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}

