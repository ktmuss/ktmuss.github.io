package com.example.keith_mussino_event_tracker_project;

//ENHANCEMENT MILESTONE 3
//the event class will define the data model for an event in the app
//each event will have a unique ID, name, and date
public class Event {

    //variables for the database
    private int id;
    private String name;
    private String date;

    //constructor to create event object with three fields
    public Event(int id, String name, String date){

        this.id = id;
        this.name = name;
        this.date = date;
    }

    //getter for event Id
    public int getId(){

        return id;
    }

    //getter and setter for event name
    public String getName() {

        return name;
    }

    public void setName(String name){

        this.name = name;
    }

    //getter and setter for event date
    public String getDate(){

        return date;
    }

    public void setDate(String date){

        this.date = date;
    }
}
