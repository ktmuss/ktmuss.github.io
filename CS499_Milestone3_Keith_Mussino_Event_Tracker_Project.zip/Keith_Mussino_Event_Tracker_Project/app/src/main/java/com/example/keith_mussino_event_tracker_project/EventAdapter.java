package com.example.keith_mussino_event_tracker_project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    //list of events
    private List<Event> eventList;

    //context to access layout inflater
    private Context context;

    //interfaces for button actions
    public interface OnEditClickListener {

        void onEditClick(Event event);
    }

    public interface OnDeleteClickListener {

        void onDeleteClick(Event event);
    }

    private OnEditClickListener editClickListener;
    private OnDeleteClickListener deleteClickListener;

    //constructor for the adapter
    public EventAdapter(Context context, List<Event> eventList, OnEditClickListener editClickListener, OnDeleteClickListener deleteClickListener) {

        this.context = context;
        this.eventList = eventList;
        this.editClickListener = editClickListener;
        this.deleteClickListener = deleteClickListener;
    }

    //viewholder class that holds references to the vies in each row item
    public static class EventViewHolder extends RecyclerView.ViewHolder {

        TextView eventName, eventDate;
        Button editButton, deleteButton;

        public EventViewHolder(@NonNull View itemView) {

            super(itemView);

            //Initialize views in the layout
            eventName = itemView.findViewById(R.id.textEventName);
            eventDate = itemView.findViewById(R.id.textEventDate);
            editButton = itemView.findViewById(R.id.buttonEdit);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
        }
    }

    //creates interface to handle edit button clicks outside the adapter
    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //Inflate teh custom row layout for each event item
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(view);
    }

    //bind data to each ViewHolder
    //called when each item scrolls into view
    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {

        //gets event object for this position
        Event currentEvent = eventList.get(position);

        //binds event name and date to the text views
        holder.eventName.setText(currentEvent.getName());
        holder.eventDate.setText(currentEvent.getDate());

        //sets click listener for edit button
        holder.editButton.setOnClickListener(v -> {

            if (editClickListener != null) {

                editClickListener.onEditClick(currentEvent);
            }
        });

        holder.deleteButton.setOnClickListener(v -> {

            if (deleteClickListener != null) {

                deleteClickListener.onDeleteClick(currentEvent);
            }
        });
    }

    //returns total number of items
    @Override
    public int getItemCount() {

        return eventList.size();
    }

    //update the adapters data if the list changes
    public void updateEventList(List<Event> updatedList) {

        this.eventList = updatedList;
        notifyDataSetChanged(); //refreshes recyclerView
    }
}
