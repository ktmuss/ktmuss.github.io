package com.example.keith_mussino_event_tracker_project;

import android.content.Intent;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

//serves as the apps initial entry point
//redirects user to LoginActivity
public class MainActivity extends AppCompatActivity{

    //@Override
    protected void OnCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);

        //redirect the user to the LoginActivity
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);

        startActivity(intent);

        //close MainActivity
        finish();
    }

}
