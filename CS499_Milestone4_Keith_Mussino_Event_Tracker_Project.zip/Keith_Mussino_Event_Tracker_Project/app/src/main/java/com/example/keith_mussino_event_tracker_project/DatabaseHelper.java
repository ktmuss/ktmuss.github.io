package com.example.keith_mussino_event_tracker_project;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {

    //database name and version
    private static final String DATABASE_NAME = "eventTracker.db";
    private static final int DATABASE_VERSION = 2;

    //user table and columns
    public static final String USER_TABLE = "users";
    public static final String USERNAME_COLUMN = "username";
    public static final String PASSWORD_COLUMN = "password";

    //event table and columns
    public static final String EVENTS_TABLE = "events";
    public static final String EVENT_ID_COLUMN = "id";
    public static final String EVENT_NAME_COLUMN = "name";
    public static final String EVENT_DATE_COLUMN = "date";

    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //create tables
    @Override
    public void onCreate(SQLiteDatabase db){

        //SQL for user table
        String CREATE_USERS_TABLE = "CREATE TABLE " + USER_TABLE + "(" +
                USERNAME_COLUMN + " TEXT PRIMARY KEY, " +
                PASSWORD_COLUMN + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        //sql for events table
        String CREATE_EVENTS_TABLE = "CREATE TABLE " + EVENTS_TABLE + "(" +
                EVENT_ID_COLUMN + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_NAME_COLUMN + " TEXT, " +
                EVENT_DATE_COLUMN + " TEXT)";
        db.execSQL(CREATE_EVENTS_TABLE);
    }

    //upgrade db
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

        //drops old table and recreates it
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS events");

        onCreate(db);
    }

    //insert new user
    public boolean registerUser(String username, String password){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USERNAME_COLUMN, username);
        values.put(PASSWORD_COLUMN, password);

        long result = db.insert(USER_TABLE, null, values);

        return result != -1;//returns true if insert was a success
    }

    //check login credentials
    public boolean validLogin(String username, String password){

        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + USER_TABLE + " WHERE " +
                USERNAME_COLUMN + "=? AND " + PASSWORD_COLUMN + "=?";

        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean isValid = cursor.getCount() > 0;

        cursor.close();

        return isValid;
    }

    //new event insertion
    public boolean addEvent(String name, String date){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(EVENT_NAME_COLUMN, name);
        values.put(EVENT_DATE_COLUMN, date);

        long result = db.insert(EVENTS_TABLE, null, values);

        return result != -1;
    }

    //get events
    public Cursor getEvents(){

        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + EVENTS_TABLE, null);
    }

    //delete event
    public boolean deleteEvent(int id){

        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(EVENTS_TABLE, EVENT_ID_COLUMN + "=?",
                new String[]{String.valueOf(id)}) > 0;
    }

    //update event
    //Enhanced update, updates an existing event by ID with new name and date
    //was not functional before, now is functional
    public boolean updateEvent(int id, String newName, String newDate){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(EVENT_NAME_COLUMN, newName);

        values.put(EVENT_DATE_COLUMN, newDate);

        //update() returns number of rows affected
        int rowsAffected = db.update(
                EVENTS_TABLE,
                values,
                EVENT_ID_COLUMN + " = ? ",
                new String[]{String.valueOf(id)}
        );

        return rowsAffected > 0;//return true if a min of one row is updated
    }

    //enhancement
    //filters and returns events by date for search feature
    public Cursor getEventsByDate(String date) {

        SQLiteDatabase db = this.getReadableDatabase();//gets read access

        //query events where date match input
        return db.rawQuery("SELECT * FROM " + EVENTS_TABLE + " WHERE " + EVENT_DATE_COLUMN + " = ?", new String[]{date});
    }

}
