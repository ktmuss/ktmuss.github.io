package com.example.keith_mussino_event_tracker_project;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.annotation.NonNull;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;
    private Button sendSmsButton;
    private EditText phoneNumberInput, messageInput;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_permission_activity);

        //initialize views fromm layout
        sendSmsButton = findViewById(R.id.buttonSendSMS);
        phoneNumberInput = findViewById(R.id.editPhoneNumber);
        messageInput = findViewById(R.id.editMessage);

        //check permission
        if(!hasSmsPermission()){

            requestSmsPermission();
        }

        //set click listener for send button
        sendSmsButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //if permission granted, sends sms
                if(hasSmsPermission()){

                    sendSms();
                }
                else{//else, requests permission

                    Toast.makeText(SmsPermissionActivity.this, "Permission not granted.", Toast.LENGTH_SHORT).show();

                    requestSmsPermission();
                }
            }
        });
    }

    //checks for sms permission
    private boolean hasSmsPermission(){

        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    //request permission
    private void requestSmsPermission(){

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    //handles permission response
    //@Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantedResults){

        super.onRequestPermissionsResult(requestCode, permissions, grantedResults);

        if(requestCode == SMS_PERMISSION_CODE){

            if(grantedResults.length > 0 && grantedResults[0] == PackageManager.PERMISSION_GRANTED){

                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            }
            else{

                Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //sends sms
    private void sendSms(){

        String phoneNumber = phoneNumberInput.getText().toString().trim();
        String message = messageInput.getText().toString().trim();

        if(!phoneNumber.isEmpty() && !message.isEmpty()){

            try{
                SmsManager sms = SmsManager.getDefault();

                sms.sendTextMessage(phoneNumber, null, message, null, null);

                Toast.makeText(this, "SMS sent = success", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS sent = failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
        Toast.makeText(this, "Enter phone number and message", Toast.LENGTH_SHORT).show();
        }

    }
}
