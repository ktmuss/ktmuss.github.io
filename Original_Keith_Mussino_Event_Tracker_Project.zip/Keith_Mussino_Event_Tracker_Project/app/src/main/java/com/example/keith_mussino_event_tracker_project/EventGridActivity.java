package com.example.keith_mussino_event_tracker_project;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;

public class EventGridActivity extends AppCompatActivity{

    //UI variables
    private TableLayout eventTable;
    private EditText eventNameInput, eventDateInput;
    private Button addButton, buttonGoToSMS;

    //Sqlite helper
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_grid_activity);

        //get reference to UI
        eventTable = findViewById(R.id.eventTable);
        eventNameInput = findViewById(R.id.editEventName);
        eventDateInput = findViewById(R.id.editEventDate);
        addButton = findViewById(R.id.buttonAddEvent);
        buttonGoToSMS = findViewById(R.id.buttonGoToSMS);

        //DatabaseHelper instance
        dbHelper = new DatabaseHelper(this);

        //load events form database and display to app
        loadEventsFromDataBase();

        //set up add button
        addButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){

                String name = eventNameInput.getText().toString().trim();
                String date = eventDateInput.getText().toString().trim();

                //validate input fields
                if(!name.isEmpty() && !date.isEmpty()){

                    boolean added = dbHelper.addEvent(name, date);

                    if(added){

                        //clear fields
                        eventNameInput.setText("");
                        eventDateInput.setText("");

                        //refresh displayed event list

                        loadEventsFromDataBase();
                    }
                }
            }
        });

        //set listener to open sms screen
        buttonGoToSMS.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){

                startActivity(new Intent(EventGridActivity.this, SmsPermissionActivity.class));
            }
        });
    }

    //loads events form database
    //clears current display and repopulates to match current database state
    private void loadEventsFromDataBase() {

        //clear all rows before loading fresh data
        eventTable.removeAllViews();

        //query the database for all records
        Cursor cursor = dbHelper.getEvents();

        if (cursor != null && cursor.moveToFirst()) {

            //extract event fields form db
            do {

                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID_COLUMN));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_NAME_COLUMN));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE_COLUMN));

                //add a new row to table for event
                addEventRow(id, name, date);

            } while (cursor.moveToNext());

            //close cursor after use
            cursor.close();
        }
    }
    //adds new row to table
    private void addEventRow(int id, String name, String date){

        TableRow row = new TableRow(this);//create new table

        //create TextView for event name
        TextView nameColumn = new TextView(this);
        nameColumn.setText(name);
        nameColumn.setPadding(16,16,16,16);

        //create TextView for event date
        TextView dateColumn = new TextView(this);
        dateColumn.setText(date);
        dateColumn.setPadding(16,16,16,16);

        //creates delete button
        Button delete = new Button(this);
        delete.setText("Delete");

        //sets click listener to delete event form db and refresh table
        delete.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){

                //remove row
                dbHelper.deleteEvent(id);//deletes data

                loadEventsFromDataBase();//refresh table
            }
        });

            //add views to row
            row.addView(nameColumn);
            row.addView(dateColumn);
            row.addView(delete);

            //add row to table layout
            eventTable.addView(row);
        }
    }

